// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Navbar scroll effect
const navbar = document.querySelector('.navbar');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
        navbar.classList.remove('scroll-up');
        return;
    }
    
    if (currentScroll > lastScroll && !navbar.classList.contains('scroll-down')) {
        navbar.classList.remove('scroll-up');
        navbar.classList.add('scroll-down');
    } else if (currentScroll < lastScroll && navbar.classList.contains('scroll-down')) {
        navbar.classList.remove('scroll-down');
        navbar.classList.add('scroll-up');
    }
    lastScroll = currentScroll;
});

// Animated candlestick chart
class CandlestickChart {
    constructor(container) {
        this.container = container;
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
        this.container.appendChild(this.canvas);
        this.resize();
        this.init();
    }

    resize() {
        this.canvas.width = this.container.clientWidth;
        this.canvas.height = this.container.clientHeight;
    }

    init() {
        // Generate sample data
        this.data = this.generateData();
        this.draw();
        
        // Animate
        setInterval(() => {
            this.data.push(this.generateCandle());
            this.data.shift();
            this.draw();
        }, 2000);
    }

    generateData() {
        const data = [];
        let price = 100;
        
        for (let i = 0; i < 20; i++) {
            data.push(this.generateCandle(price));
            price = data[data.length - 1].close;
        }
        
        return data;
    }

    generateCandle(lastPrice = 100) {
        const volatility = 5;
        const open = lastPrice;
        const close = open + (Math.random() - 0.5) * volatility;
        const high = Math.max(open, close) + Math.random() * volatility;
        const low = Math.min(open, close) - Math.random() * volatility;
        
        return { open, high, low, close };
    }

    draw() {
        const ctx = this.ctx;
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Calculate scales
        const padding = 20;
        const chartWidth = width - padding * 2;
        const chartHeight = height - padding * 2;
        
        const minPrice = Math.min(...this.data.map(d => d.low));
        const maxPrice = Math.max(...this.data.map(d => d.high));
        const priceRange = maxPrice - minPrice;
        
        const candleWidth = chartWidth / this.data.length;
        const priceScale = chartHeight / priceRange;
        
        // Draw candlesticks
        this.data.forEach((candle, i) => {
            const x = padding + i * candleWidth;
            const y = height - padding - (candle.close - minPrice) * priceScale;
            
            // Draw wick
            ctx.beginPath();
            ctx.moveTo(x + candleWidth / 2, height - padding - (candle.high - minPrice) * priceScale);
            ctx.lineTo(x + candleWidth / 2, height - padding - (candle.low - minPrice) * priceScale);
            ctx.strokeStyle = candle.close >= candle.open ? '#10b981' : '#ef4444';
            ctx.stroke();
            
            // Draw body
            ctx.fillStyle = candle.close >= candle.open ? '#10b981' : '#ef4444';
            ctx.fillRect(
                x + 2,
                height - padding - (Math.max(candle.open, candle.close) - minPrice) * priceScale,
                candleWidth - 4,
                Math.abs(candle.close - candle.open) * priceScale
            );
        });
    }
}

// Initialize charts when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Hero chart
    const heroChart = new CandlestickChart(document.querySelector('.chart-container'));
    
    // Candlestick section chart
    const candlestickChart = new CandlestickChart(document.querySelector('.candlestick-chart'));
    
    // Handle window resize
    window.addEventListener('resize', () => {
        heroChart.resize();
        candlestickChart.resize();
    });

    // Mobile menu toggle
    const burger = document.querySelector('.burger');
    const mobileMenu = document.getElementById('mobile-menu');
    if (burger && mobileMenu) {
        const handleToggleMenu = () => {
            const isOpen = mobileMenu.hasAttribute('open');
            if (isOpen) {
                mobileMenu.removeAttribute('open');
                burger.setAttribute('aria-expanded', 'false');
            } else {
                mobileMenu.setAttribute('open', '');
                burger.setAttribute('aria-expanded', 'true');
            }
        };
        burger.addEventListener('click', handleToggleMenu);
        burger.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') handleToggleMenu();
        });
        // Закрытие меню по клику на ссылку
        mobileMenu.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.removeAttribute('open');
                burger.setAttribute('aria-expanded', 'false');
            });
        });
        // Закрытие по клику вне меню
        document.addEventListener('click', (e) => {
            if (!mobileMenu.contains(e.target) && !burger.contains(e.target)) {
                mobileMenu.removeAttribute('open');
                burger.setAttribute('aria-expanded', 'false');
            }
        });
    }
});

// Form submission
const ctaForm = document.querySelector('.cta-form');
if (ctaForm) {
    ctaForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = ctaForm.querySelector('input[type="email"]').value;
        
        // Here you would typically send the email to your backend
        console.log('Form submitted with email:', email);
        
        // Show success message
        const successMessage = document.createElement('div');
        successMessage.className = 'success-message';
        successMessage.textContent = 'Thank you for subscribing!';
        ctaForm.appendChild(successMessage);
        
        // Clear form
        ctaForm.reset();
        
        // Remove success message after 3 seconds
        setTimeout(() => {
            successMessage.remove();
        }, 3000);
    });
}

// Intersection Observer for scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe elements for scroll animations
document.querySelectorAll('.trading-card, .candlestick-content, .feature').forEach(el => {
    observer.observe(el);
}); 