import { initHeader } from './modules/header.js';
import { initCategories } from './modules/categories.js';
import { initTestimonials } from './modules/testimonials.js';
import { initForms } from './modules/forms.js';
import { initScrollAnimations } from './modules/animations.js';
import { initBackToTop } from './modules/backToTop.js';

// Initialize all modules when DOM is fully loaded
$(document).ready(function() {
  // Initialize header behavior
  initHeader();
  
  // Initialize category tabs
  initCategories();
  
  // Initialize testimonials slider
  initTestimonials();
  
  // Initialize form handling
  initForms();
  
  // Initialize scroll animations
  initScrollAnimations();
  
  // Initialize back to top button
  initBackToTop();
  
  // Trigger initial animations
  $('.book-card').addClass('active');
});