/**
 * Back to top button functionality
 * - Shows/hides back to top button based on scroll position
 * - Handles smooth scrolling to top when button is clicked
 */
export function initBackToTop() {
  const $backToTopButton = $('.back-to-top');
  
  // Show/hide button based on scroll position
  $(window).on('scroll', function() {
    if ($(window).scrollTop() > 300) {
      $backToTopButton.addClass('visible');
    } else {
      $backToTopButton.removeClass('visible');
    }
  });
  
  // Smooth scroll to top when button is clicked
  $backToTopButton.on('click', function(e) {
    e.preventDefault();
    
    $('html, body').animate({
      scrollTop: 0
    }, 800, 'swing');
  });
}