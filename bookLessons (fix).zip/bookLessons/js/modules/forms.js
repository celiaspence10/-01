/**
 * Form handling functionality
 * - Validates form inputs
 * - Handles form submissions
 * - Shows success/error messages
 */
export function initForms() {
  const $subscribeForm = $('#subscribe-form');
  const $contactForm = $('#contact-form');
  
  // Subscribe form submission
  $subscribeForm.on('submit', function(e) {
    e.preventDefault();
    
    // Simple validation
    const name = $('#name').val().trim();
    const email = $('#email').val().trim();
    
    if (name === '' || email === '') {
      showFormMessage($subscribeForm, 'Please fill in all required fields', 'error');
      return;
    }
    
    // Email format validation
    if (!isValidEmail(email)) {
      showFormMessage($subscribeForm, 'Please enter a valid email address', 'error');
      return;
    }
    
    // Simulate successful form submission
    showFormMessage($subscribeForm, 'Thank you for subscribing! Check your email for confirmation.', 'success');
    $subscribeForm[0].reset();
  });
  
  // Contact form submission
  $contactForm.on('submit', function(e) {
    e.preventDefault();
    
    // Simple validation
    const name = $('#contact-name').val().trim();
    const email = $('#contact-email').val().trim();
    const bookTitle = $('#book-title').val().trim();
    const message = $('#message').val().trim();
    
    if (name === '' || email === '' || bookTitle === '' || message === '') {
      showFormMessage($contactForm, 'Please fill in all required fields', 'error');
      return;
    }
    
    // Email format validation
    if (!isValidEmail(email)) {
      showFormMessage($contactForm, 'Please enter a valid email address', 'error');
      return;
    }
    
    // Simulate successful form submission
    showFormMessage($contactForm, 'Your book recommendation has been submitted! Thank you for your contribution.', 'success');
    $contactForm[0].reset();
  });
  
  // Helper function to validate email format
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }
  
  // Helper function to show form messages
  function showFormMessage($form, message, type) {
    // Remove any existing message
    $form.find('.form-message').remove();
    
    // Create message element
    const $messageElement = $('<div>', {
      class: `form-message ${type}`,
      text: message
    });
    
    // Add message to form
    $form.prepend($messageElement);
    
    // Auto-remove message after 5 seconds
    setTimeout(() => {
      $messageElement.fadeOut(300, function() {
        $(this).remove();
      });
    }, 5000);
  }
  
  // Add form message styles
  const formMessageStyles = `
    .form-message {
      padding: 12px;
      margin-bottom: 16px;
      border-radius: 4px;
      font-weight: 600;
    }
    .form-message.success {
      background-color: rgba(46, 125, 50, 0.1);
      color: #2E7D32;
      border-left: 4px solid #2E7D32;
    }
    .form-message.error {
      background-color: rgba(198, 40, 40, 0.1);
      color: #C62828;
      border-left: 4px solid #C62828;
    }
  `;
  
  // Add styles to head
  $('<style>').text(formMessageStyles).appendTo('head');
}