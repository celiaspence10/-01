/**
 * Header functionality
 * - Handles transparent/solid header on scroll
 * - Manages mobile menu toggling
 * - Implements smooth scrolling for navigation links
 */
export function initHeader() {
  const $header = $('#header');
  const $mobileMenuToggle = $('.mobile-menu-toggle');
  const $navList = $('.nav-list');
  const $navLinks = $('.nav-link');
  
  // Handle header transparency on scroll
  $(window).on('scroll', function() {
    if ($(window).scrollTop() > 50) {
      $header.addClass('scrolled');
    } else {
      $header.removeClass('scrolled');
    }
  });
  
  // Trigger scroll event on page load to set initial state
  $(window).trigger('scroll');
  
  // Mobile menu toggle
  $mobileMenuToggle.on('click', function() {
    $(this).toggleClass('active');
    $navList.toggleClass('active');
    $('body').toggleClass('menu-open');
  });
  
  // Close mobile menu when clicking a link
  $navLinks.on('click', function() {
    $mobileMenuToggle.removeClass('active');
    $navList.removeClass('active');
    $('body').removeClass('menu-open');
  });
  
  // Smooth scroll for navigation links
  $navLinks.on('click', function(e) {
    const href = $(this).attr('href');
    
    // If the link contains a hash and is on the same page
    if (href.includes('#') && !href.includes('index.html')) {
      e.preventDefault();
      const target = href;
      
      $('html, body').animate({
        scrollTop: $(target).offset().top - 80
      }, 800, 'swing');
    }
    // If the link is to another page with a hash, let the browser handle it
    // This will allow the browser to navigate to the page and then scroll to the section
  });
}