/**
 * Scroll animations functionality
 * - Manages reveal animations on scroll
 * - Handles element visibility detection
 * - Adds animation classes to elements when they enter the viewport
 */
export function initScrollAnimations() {
  const $animatedElements = $('.reveal, .reveal-left, .reveal-right, .book-card');
  
  // Function to check if element is in viewport
  function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.85 &&
      rect.bottom >= 0
    );
  }
  
  // Function to handle scroll animation
  function handleScrollAnimation() {
    $animatedElements.each(function() {
      if (isElementInViewport(this)) {
        $(this).addClass('active');
      }
    });
  }
  
  // Bind scroll event
  $(window).on('scroll', handleScrollAnimation);
  
  // Trigger check on page load
  handleScrollAnimation();
  
  // Add section-specific animations
  $('.section-header').addClass('reveal');
  $('.testimonial').addClass('reveal');
  $('.subscribe-info').addClass('reveal-left');
  $('.subscribe-form-container').addClass('reveal-right');
  $('.contact-form').addClass('reveal');
  
  // Add staggered animations to benefits list
  $('.benefit-item').each(function(index) {
    $(this).addClass('reveal');
    $(this).css('transition-delay', `${0.1 * (index + 1)}s`);
  });
}