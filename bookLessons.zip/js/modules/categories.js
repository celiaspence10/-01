/**
 * Categories tab functionality
 * - Manages tab switching between book categories
 * - Handles active states for tabs and panels
 */
export function initCategories() {
  const $tabControls = $('.tab-control');
  const $tabPanels = $('.tab-panel');
  
  // Tab switching functionality
  $tabControls.on('click', function() {
    const category = $(this).data('category');
    
    // Update active tab control
    $tabControls.removeClass('active');
    $(this).addClass('active');
    
    // Update active tab panel
    $tabPanels.removeClass('active');
    $tabPanels.filter(`[data-category="${category}"]`).addClass('active');
    
    // Activate animations for the newly visible book cards
    $('.book-card').removeClass('active');
    setTimeout(() => {
      $('.book-card').addClass('active');
    }, 50);
  });
}