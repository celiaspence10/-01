/**
 * Testimonials slider functionality
 * - Manages testimonial slider navigation
 * - Handles dot indicators
 * - Implements automatic sliding with pause on hover
 */
export function initTestimonials() {
  const $testimonials = $('.testimonial');
  const $prevButton = $('.testimonial-control.prev');
  const $nextButton = $('.testimonial-control.next');
  const $dots = $('.dot');
  
  let currentIndex = 0;
  const testimonialCount = $testimonials.length;
  let autoplayInterval;
  
  // Function to show testimonial by index
  function showTestimonial(index) {
    // Update testimonials
    $testimonials.removeClass('active');
    $testimonials.eq(index).addClass('active');
    
    // Update dots
    $dots.removeClass('active');
    $dots.eq(index).addClass('active');
    
    // Update current index
    currentIndex = index;
  }
  
  // Initialize first testimonial
  showTestimonial(0);
  
  // Previous button click handler
  $prevButton.on('click', function() {
    let newIndex = currentIndex - 1;
    if (newIndex < 0) {
      newIndex = testimonialCount - 1;
    }
    showTestimonial(newIndex);
  });
  
  // Next button click handler
  $nextButton.on('click', function() {
    let newIndex = currentIndex + 1;
    if (newIndex >= testimonialCount) {
      newIndex = 0;
    }
    showTestimonial(newIndex);
  });
  
  // Dot click handler
  $dots.on('click', function() {
    const index = $(this).index();
    showTestimonial(index);
  });
  
  // Autoplay function
  function startAutoplay() {
    autoplayInterval = setInterval(function() {
      let newIndex = currentIndex + 1;
      if (newIndex >= testimonialCount) {
        newIndex = 0;
      }
      showTestimonial(newIndex);
    }, 5000);
  }
  
  // Start autoplay
  startAutoplay();
  
  // Pause autoplay on hover
  $('.testimonials-slider').hover(
    function() {
      clearInterval(autoplayInterval);
    },
    function() {
      startAutoplay();
    }
  );
}