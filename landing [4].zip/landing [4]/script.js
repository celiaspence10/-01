$(document).ready(function() {
    // Initialize Swiper
    const swiper = new Swiper('.strategies-slider', {
        slidesPerView: 1,
        spaceBetween: 30,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
            },
            1024: {
                slidesPerView: 3,
            },
        },
        autoplay: {
            delay: 5000,
            disableOnInteraction: false,
        },
    });

    // Mobile menu toggle
    const mobileMenuButton = $('#mobile-menu-button');
    const mobileMenu = $('<div class="mobile-menu"></div>');
    
    // Create mobile menu content
    const mobileMenuContent = `
        <div class="flex flex-col h-full">
            <div class="flex justify-between items-center mb-8">
                <a href="#" class="text-2xl font-bold text-blue-900">TradeLearn</a>
                <button class="close-menu">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
            <div class="flex flex-col space-y-4">
                <a href="#principles" class="text-xl hover:text-blue-600 transition-colors">Principles</a>
                <a href="#strategies" class="text-xl hover:text-blue-600 transition-colors">Strategies</a>
                <a href="#risks" class="text-xl hover:text-blue-600 transition-colors">Risks</a>
                <a href="#faq" class="text-xl hover:text-blue-600 transition-colors">FAQ</a>
            </div>
        </div>
    `;
    
    mobileMenu.html(mobileMenuContent);
    $('body').append(mobileMenu);

    // Toggle mobile menu
    mobileMenuButton.on('click', function() {
        mobileMenu.addClass('active');
    });

    $('.close-menu').on('click', function() {
        mobileMenu.removeClass('active');
    });

    // Close mobile menu when clicking a link
    mobileMenu.find('a').on('click', function() {
        mobileMenu.removeClass('active');
    });

    // Smooth scroll for anchor links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        const target = $(this.hash);
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 80
            }, 800);
        }
    });

    // Add animation classes on scroll
    const animateOnScroll = function() {
        $('.p-6').each(function() {
            const elementTop = $(this).offset().top;
            const elementBottom = elementTop + $(this).outerHeight();
            const viewportTop = $(window).scrollTop();
            const viewportBottom = viewportTop + $(window).height();

            if (elementBottom > viewportTop && elementTop < viewportBottom) {
                $(this).addClass('animate-fade-in');
            }
        });
    };

    // Initial check for elements in viewport
    animateOnScroll();

    // Check for elements in viewport on scroll
    $(window).on('scroll', animateOnScroll);

    // Add hover scale effect to cards
    $('.p-6').addClass('hover-scale');
}); 