$(document).ready(function() {
    // Mobile menu toggle
    $('.menu-toggle').on('click', function() {
        const $this = $(this);
        const $navList = $('.nav-list');
        
        $this.attr('aria-expanded', $this.attr('aria-expanded') === 'false' ? 'true' : 'false');
        $navList.toggleClass('active');
    });

    // Close mobile menu when clicking outside
    $(document).on('click', function(e) {
        if (!$(e.target).closest('.nav').length) {
            $('.nav-list').removeClass('active');
            $('.menu-toggle').attr('aria-expanded', 'false');
        }
    });

    // Smooth scroll for anchor links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        const target = $(this.hash);
        
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 80 // Offset for fixed header
            }, 500);
        }
    });

    // Add active class to current navigation item
    const currentPath = window.location.pathname;
    $('.nav-list a').each(function() {
        const $this = $(this);
        if ($this.attr('href') === currentPath) {
            $this.addClass('active');
        }
    });
}); 